# Databricks notebook source
data=spark.read.csv("/FileStore/tables/Customers.csv",header=True)
data.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Exploratory Data Analysis (EDA) is a critical step in understanding and summarizing the data before applying machine learning models or performing advanced data processing. 
# MAGIC
# MAGIC

# COMMAND ----------

data.printSchema()

# COMMAND ----------

# changing data types
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DoubleType,DateType
data=data.withColumn("CustomerID",data["CustomerKey"].cast(IntegerType()))\
         .withColumn("State code",data["State Code"].cast(IntegerType()))\
         .withColumn("Zip Code",data["Zip Code"].cast(IntegerType()))\
        .withColumn("BirthDate",data["Birthday"].cast(DateType()))
data.printSchema()

# COMMAND ----------

data.describe().show()

# COMMAND ----------

# total rows
print("Row count:",data.count())
# total columns
print("Column count:",len(data.columns))

# COMMAND ----------

