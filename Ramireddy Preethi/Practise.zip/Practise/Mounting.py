# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.myspace12.dfs.core.windows.net", "vh1aY/AqJJt4benIzImHh6rzbk8qt/lDVUFWWHj9XEVJvJaUnnoCc00EfaYVEP3p1GQKlnfuvoHz+AStI7gFXA=="
)

# COMMAND ----------

dbutils.fs.ls("abfss://input@myspace12.dfs.core.windows.net/")

# COMMAND ----------

df=spark.read.format("csv").load("abfss://input@myspace12.dfs.core.windows.net/Customers.csv",header=True,inferSchema=True)
df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC These spark.conf.set configurations are used to enable Apache Spark to access an Azure Data Lake Storage Gen2 account using a SAS (Shared Access Signature) token for authentication.
# MAGIC
# MAGIC fs.azure.account.auth.type specifies the type of authentication to use for the storage account. : Replace this placeholder with the name of your Azure storage account. For example, if your account is mystorage, this becomes mystorage.dfs.core.windows.net. "SAS" tells Spark that access to the storage account will be provided using a SAS token.

# COMMAND ----------

# set the authentication type
spark.conf.set("fs.azure.account.auth.type.myspace12.dfs.core.windows.net", "SAS")

# COMMAND ----------

# MAGIC %md
# MAGIC fs.azure.sas.token.provider.type specifies the type of provider that Spark should use to retrieve the SAS token. org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider is the class provided by Azure's Hadoop-based library to handle SAS tokens as fixed strings. This configuration ensures that Spark will use the SAS token directly from the next configuration (below).

# COMMAND ----------

# set the SAS token provider type
spark.conf.set("fs.azure.sas.token.provider.type.myspace12.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")

# COMMAND ----------

# provide SAS token
spark.conf.set("fs.azure.sas.fixed.token.myspace12.dfs.core.windows.net", "sv=2022-11-02&ss=bfqt&srt=c&sp=rwdlacupyx&se=2024-11-26T14:53:42Z&st=2024-11-26T06:53:42Z&spr=https&sig=PCvGynIDwUKkRxfD6ecVijYnDy0X%2B%2BQcIx7jb56j06w%3D")

# COMMAND ----------

sas_token="sv=2022-11-02&ss=bfqt&srt=c&sp=rwdlacupyx&se=2024-11-26T14:41:02Z&st=2024-11-26T06:41:02Z&spr=https&sig=Cc0jREIxNN9WEqfaOg8aHAiOGqfj44mcQthTzo2mUaE%3D"
print(sas_token)

# COMMAND ----------

dbutils.fs.ls("abfss://input@myspace12.dfs.core.windows.net/")


# COMMAND ----------

# MAGIC %md
# MAGIC Service Principal

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": "9a08d25c-0b43-49be-bfee-a9210dee2c0a",
          "fs.azure.account.oauth2.client.secret": "shC8Q~QhmJ4qumVWuqBW6y8_Uj1tCkPS~ejEnaSR",
          "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/7540734b-e567-46c3-9ad3-ec9fb9e50140/oauth2/token"}

# Optionally, you can add <directory-name> to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://input@myspace12.dfs.core.windows.net/",
  mount_point = "/mnt/input",
  extra_configs = configs)